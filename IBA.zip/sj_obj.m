%-----------------------------------------------------------------------%
% SJ_OBJ matches predicted and observed prices of homes                 %
%                                                                       %
%function Q=sj_obj(beta,I,K,y1,X2,sjprice)                              %
%                                                                       %
% INPUTS                                                                %
%   beta:           vector of parameters for pref distribution          %
%   I:      1x1     # simulation draws                                  %
%   K:      1x1     # characteristics of each home                      %
%   y1:     Ix1     vector of income for households                     %
%   X2:     KxI     matrix of housing characteristics                   %
%   sjprice: Ix1     vector of actual housing prices                    %
% OUTPUTS                                                               %
%   Q:      ML objective function                                       %
%-----------------------------------------------------------------------%
function Q=sj_obj(beta,I,K,y1,X2,sjprice)                               % define function
rand('state',2008); randn('state',2008);                                % set seed on uniform to avoid chatter
%-----------------------------------------------------------------------%
%      TAKE DRAWS ON PREFERNECES AND DEFINE CONSTANTS FOR IBA           %
%-----------------------------------------------------------------------%
alpha1=gamrnd(beta(1),beta(2),I,K);                                     % draw info on preferences                         
alpha1=(ones(I,1)*beta(3:end)).*alpha1./((y1/1000)*ones(1,K));          % disutility from negative characteristics  
u=alpha1*X2;                                                            % utility from all homes
[a b]=min(u');                                                          % lowest utility    
u1=(y1-min(y1)+1).*diag(exp(alpha1*X2(:,b)));                           % calculate utility from lowest bid
A=(1:1:I)';  priceold=zeros(I,1);  price=ones(I,1); price(1)=2000; it=0;% initial values for algorithm
%-----------------------------------------------------------------------%
%       SOLVE FOR EQUILIBRIUM PRICE VECTOR USING IBA ALGORITHM          %
%-----------------------------------------------------------------------%
while max(abs(price-priceold))>1e-2 & min(price)>0  & it<5000  & (max(price)-min(price))>1000          % iterate on price vector
    priceold=price;     it=it+1;                                        % update price vector
    for i=1:I                                                           % loop over homes                 
        M=alpha1*X2(:,i);                                               % utility from characteristics
        M=exp(M);                                                       % constant in bid function
        bid=y1-u1./M;                                                   % current bids for i
        [temp k]=max(bid);                                              % find maximum bidder
        A(i)=k;                                                         % update assignment
        bid(k)=[];                                                      % remove from sample
        z=max(bid);                                                     % find next highest bid
        price(i)=min(z(1)+sqrt(eps),temp);                              % calculate new price
        u1(k)=(y1(k)-price(i)).*M(k);                                   % update utility of mover
    end                                                                 %  
end                                                                     %  
Q=.25*norm(sjprice-price)+norm(sort(sjprice)-sort(price));              % calculate objective function
unassigned=I-size(unique(A),1);                                         % calculate performance statistics
if unassigned>0 | (min(price))<0, Q=Q^2; end                            % punish obj function for poor performance
%-----------------------------------------------------------------------%




























