%-----------------------------------------------------------------------%
% MULTIPLICITY                                                          %
%                                                                       %    
% This file identifies multiple equilibria by systematically varying    %
% the reference consumption bundle.  The results are used to draw fig 4.%
%                                                                       %
% Note: the price and structural characteristics of each home have been %
%       altered in order to avoid violating contract obligations with   %
%       the commercial vendor supplying the data. As a result, these    %
%       "fake" housing data cannot be used for any other application.   %
%       They have no value outside the current simulation.  See the     %
%       appendix to the paper for details.                              % 
%-----------------------------------------------------------------------%
clear                                                                   % clear all data in workspace
rand('state',2008); randn('state',2008);                                % set seeds on uniform and normal distributions
opt=optimset('Display','iter','TolFun',1e-4,'TolX',1e-4,'MaxIter',1e+6,'MaxFunEval',1e+6); 
%-----------------------------------------------------------------------%
%   1.  LOAD DATA & DEFINE VARIABLES                                    %
%-----------------------------------------------------------------------%
load sjdata                                                             % load San Joaquin data
%-----------------------------------------------------------------------%
%   2.  DATA DESCRIPTION                                                %
%-----------------------------------------------------------------------%
%       sjprice  --> housing prices                                     %
%       rent     --> annualized rents using formula from Poterba (1992) %
%       API      --> Academic performance index                         %
%       N        --> # observations                                     %
%       K        --> # characteristics                                  %
%       X(:,1)   --> building sqft (10)                                 %
%       X(:,2)   --> lot sqft (1000)                                    %
%       X(:,3)   --> bedrooms (#)                                       %
%       X(:,4)   --> age (years)                                        %
%       X(:,5)   --> % in cesus tract under 18 (%)                      %
%       X(:,6)   --> distance to nearest grazing land (kilometers)      %
%       X(:,7)   --> mean travel time to work in tract (kilometers)     %
%       X(:,8)   --> median household income in tract (1000)            %
%       X(:,9)   --> distance to nearest water body (kilometers)        %
%       X(:,10)   --> STAR mean 10th grade math score (percentile)      %
%       API      --> Academic Performance Index in 1999 (percentile)    %
%-----------------------------------------------------------------------%
%-----------------------------------------------------------------------%
%   3.  DEFINE INCOME FOR POPULATION OF HOUSEHOLDS                      %
%-----------------------------------------------------------------------%
incmin=[0 5 10 15 20 25 30 35 40 45 50 60 75 100 125 150 200];          % lower bound on income bins
incmax=[5 10 15 20 25 30 35 40 45 50 60 75 100 125 150 200 300];        % upper bound on income bins
inccount=[6942 11376 12234 12129 11924 11794 10694 10603 10187 8940];   % income distribution
inccount=[inccount 16076 19399 19934 9405 4016 3212 2701];              % income distribution
incmin(1)=[];   incmax(1)=[];   inccount(1)=[];                         % drop lowest bin (<$10,000)
y=[];                                                                   %
for i=1:length(inccount)                                                % loop over income bins
    temp=incmin(i)+(incmax(i)-incmin(i))*rand(inccount(i),1);           % draws on income for people in bin
    y=[y; temp*1000];                                                   % concatinate income distribution & convert to dollars
end                                                                     %
%-----------------------------------------------------------------------%
%   4.  SOLVE FOR PREFERENCES WHICH MATCH PREDICTED & OBSERVED PRICES   %
%-----------------------------------------------------------------------%
I=50;                                                                   % sample size for calibration
temp=(100/I:100/I:100)';                                                % select quantiles in proportion to sample size
y1=quantile(y,temp/100);                                                % approximate income distribution
indx=quantile(rent,temp/100);                                           % draw I from N without replacement
indx1=[];                                                               %
for i=1:I                                                               % loop over sample   
    [a b]=min(abs(rent-indx(i)));                                       % draw rent quantiles
    indx(i)=rent(b); indx1=[indx1; b];                                  % store rent quantiles
end                                                                     %
X1=X(indx1,:);  X2=log(X1');                                            % log transformation of continuous characteristics
beta=[0.9782 0.1563 123.0416 14.926 -2.0896 -11.9443 -14.2792 -10.1281 3.4123 16.9954 14.4839 11.6313];
%-----------------------------------------------------------------------%
%   5.  RUN MONTE CARLO SIMULATION TO DEMONSTRATE IBA                   %
%-----------------------------------------------------------------------%
I=100;                                                                  % sample size
S=99;                                                                   % # starting points for initial utility
tol=1e-6;                                                               % convergence tolerance on price vector
iter=1;                                                                 %
id1=(1:1:I)';                                                           % id for homes in each simulation
resultP=zeros(I,S);                                                     % empty matrix of results for current simulation size
resultA=zeros(I,S);                                                     % empty matrix of results for current simulation size
test=zeros(2,S);                                                        %
indx=1:1:I;                                                             %
rent1=rent(indx);                                                       % true rent on sample homes
X1=X(indx,:);                                                           % characteristics for simulation
X2=log(X1');                                                            % log transformation of continuous characteristics 
indx1=randsample(length(y),I,'false');                                  % randomly choose household income
y1=y(indx1,:);                                                          % income for simulation
alpha1=gamrnd(beta(1),beta(2),I,K);                                     % draw info on preferences        
alpha1=(ones(I,1)*beta(3:end)).*alpha1./((y1/1000)*ones(1,K));          % disutility from negative characteristics  
u=alpha1*X2;                                                            % utility from all homes
[a b]=min(u');                                                          % lowest utility  
for s=1:S                                                               % loop over Monte Carlo simulations
    A=(1:1:I)';                                                         % initial assignment (random)
    priceold=zeros(I,1);    price=ones(I,1);                            % initial prices                                     
    it=0;                                                               % initial iteration
    %-------------------------------------------------------------------%
    %   a.  define reference utility based on s                         %
    %-------------------------------------------------------------------%
    u1=(1-.01*s)*y1.*diag(exp(alpha1*X2(:,b)));                         % reference utility
    %-------------------------------------------------------------------%
    %   b.  solve for equilibrium price vector using IBA                %
    %-------------------------------------------------------------------%
    while max(abs(price-priceold))>tol                                  % iterate on price vector
        priceold=price;                                                 % update price vector
        for i=1:I                                                       % loop over homes                 
            M=alpha1*X2(:,i);                                           % utility from characteristics
            M=exp(M);                                                   % constant in bid function
            bid=y1-u1./M;                                               % current bids for i
            [temp k]=max(bid);                                          % find maximum bidder
            A(i)=k;                                                     % update assignment
            bid(k)=[];                                                  % remove from sample
            z=max(bid);                                                 % find next highest bid
            price(i)=min(z(1)+sqrt(eps),temp);                          % calculate new price
            u1(k)=(y1(k)-price(i)).*M(k);                               % update utility of mover
        end                                                             %
        it=it+1;  unassigned=I-size(unique(A),1);                       % calculate performance statistics
        fprintf('Iter: %4i  P_min: %7.8f  P_max: %7.8f  P_diff: %.8f  Unassigned: %5.0f  MC: %4.0f\n',it,min(price),max(price),max(abs(price-priceold)),unassigned,s);   
    end                                                                 % 
    resultP(:,iter)=price;                                              % store equilibrium prices
    resultA(:,iter)=A;                                                  % store equilibrium assignment
    if iter>1,                                                          %
        if max(abs(resultP(1:I,iter-1)-resultP(1:I,iter)))>.1, test(1,iter)=1; end
        if max(abs(resultA(1:I,iter-1)-resultA(1:I,iter)))>.1, test(2,iter)=1; end
    end                                                                 %
    iter=iter+1;                                                        % update iteration number
end                                                                     %    
%-----------------------------------------------------------------------%
%   6.  SUMMARIZE RESULTS                                               %
%-----------------------------------------------------------------------%
rent=rent(indx);                                                        % 
changeP=find(test(1,:)==1);                                             %
changeA=find(test(2,:)==1);                                             %    
indx=[1 changeP];                                                       %
temp=[indx; resultP(2,indx); resultP(13,indx)];                         %
temp1=[];                                                               %            
for i=1:max(size(temp))-1                                               %
    temp1=[temp1 temp(:,i) [temp(1,i+1); temp(2:3,i)]];                 %
end                                                                     %
temp1=[temp1 temp(:,end)];                                              %
temp1=temp1';                                                           %
resultP=[resultP rent1];                                                %
%-----------------------------------------------------------------------%