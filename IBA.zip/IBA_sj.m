%-----------------------------------------------------------------------%
% IBA_SJ                                                                %
%                                                                       %    
% This file uses the data from San Joaquin County, CA to solve for a    %
% hedonic equilibrium.  It also generates table 3 and figure 3 in the   %
% paper.                                                                %
%                                                                       %
% Note 1:   the price and structural characteristics of each home have  %
%           been altered to avoid violating contract obligations with   %
%           the commercial vendor for the data. As a result, these      %
%           "fake" data have no value other than allowing others to     %
%           reproduce our simulation results.  See the appendix to the  %
%           paper for additional details.                               %
%                                                                       %
% Note 2:   the IBA code used to solve for equilibria is found on line  %
%           107 to line 122.                                            %
%-----------------------------------------------------------------------%
clear                                                                   % clear all data in workspace
rand('state',2008); randn('state',2008);                                % set seeds on uniform and normal distributions
opt=optimset('Display','iter','TolFun',1e-4,'TolX',1e-4,'MaxIter',1e+6,'MaxFunEval',1e+6); 
%-----------------------------------------------------------------------%
%   1.  LOAD DATA & DEFINE VARIABLES                                    %
%-----------------------------------------------------------------------%
load sjdata                                                             % load San Joaquin data
%-----------------------------------------------------------------------%
%   2.  DATA DESCRIPTION                                                %
%-----------------------------------------------------------------------%
%       sjprice  --> housing prices                                     %
%       rent     --> annualized rents using formula from Poterba (1992) %
%       API      --> Academic performance index                         %
%       N        --> # observations                                     %
%       K        --> # characteristics                                  %
%       X(:,1)   --> building sqft (10)                                 %
%       X(:,2)   --> lot sqft (1000)                                    %
%       X(:,3)   --> bedrooms (#)                                       %
%       X(:,4)   --> age (years)                                        %
%       X(:,5)   --> % in cesus tract under 18 (%)                      %
%       X(:,6)   --> distance to nearest grazing land (kilometers)      %
%       X(:,7)   --> mean travel time to work in tract (kilometers)     %
%       X(:,8)   --> median household income in tract (1000)            %
%       X(:,9)   --> distance to nearest water body (kilometers)        %
%       X(:,10)   --> STAR mean 10th grade math score (percentile)      %
%       API      --> Academic Performance Index in 1999 (percentile)    %
%-----------------------------------------------------------------------%
%-----------------------------------------------------------------------%
%   3.  DEFINE INCOME FOR POPULATION OF HOUSEHOLDS                      %
%-----------------------------------------------------------------------%
incmin=[0 5 10 15 20 25 30 35 40 45 50 60 75 100 125 150 200];          % lower bound on income bins
incmax=[5 10 15 20 25 30 35 40 45 50 60 75 100 125 150 200 300];        % upper bound on income bins
inccount=[6942 11376 12234 12129 11924 11794 10694 10603 10187 8940];   % income distribution
inccount=[inccount 16076 19399 19934 9405 4016 3212 2701];              % income distribution
incmin(1)=[];   incmax(1)=[];   inccount(1)=[];                         % drop lowest bin (<$10,000)
y=[];                                                                   %
for i=1:length(inccount)                                                % loop over income bins
    temp=incmin(i)+(incmax(i)-incmin(i))*rand(inccount(i),1);           % draws on income for people in bin
    y=[y; temp*1000];                                                   % concatinate income distribution & convert to dollars
end                                                                     %
%-----------------------------------------------------------------------%
%   4.  SOLVE FOR PREFERENCES WHICH MATCH PREDICTED & OBSERVED PRICES   %
%-----------------------------------------------------------------------%
I=50;                                                                   % sample size for calibration
temp=(100/I:100/I:100)';                                                % select quantiles in proportion to sample size
y1=quantile(y,temp/100);                                                % approximate income distribution
indx=quantile(rent,temp/100);                                           % draw I from N without replacement
indx1=[];                                                               %
for i=1:I                                                               % loop over sample   
    [a b]=min(abs(rent-indx(i)));                                       % draw rent quantiles
    indx(i)=rent(b); indx1=[indx1; b];                                  % store rent quantiles
end                                                                     %
X1=X(indx1,:);  X2=log(X1');                                            % log transformation of continuous characteristics
start=[0.999 0.1472 120.227 10.794 -3.2547 -12.8627 -7.5271 -11.5327 4.4708 17.6564 14.1198 15.2068]; 
% beta=fminsearch('sj_obj',start,opt,I,K,y1,X2,indx);                   % uncomment to calibrate algorithm
beta=[0.9782 0.1563 123.0416 14.926 -2.0896 -11.9443 -14.2792 -10.1281 3.4123 16.9954 14.4839 11.6313];
%-----------------------------------------------------------------------%
%   5.  RUN MONTE CARLO SIMULATION TO DEMONSTRATE IBA                   %
%-----------------------------------------------------------------------%
simsize=[200; 500; 1000; 2000];                                         %
table3=[];                                                              % empty version of table 3 
MC=30;                                                                  % # Monte Carlo simulations
tol=1e-4;                                                               % convergence tolerance on price vector
for z=1:length(simsize)                                                 % loop over simulation sizes
    I=simsize(z);                                                       % sample size for simulation
    id1=(1:1:I)';                                                       % id for homes in each simulation
    results=zeros(MC,19);                                               % empty matrix of results for current simulation size
    for mc=1:MC                                                          % loop over Monte Carlo simulations
        tic                                                             % start stopwatch
        rand('state',mc);  randn('state',mc);                           % set seeds on uniform and normal distributions
        indx=randsample(N,I,'false');                                   % draw I from N without replacement
        X1=X(indx,:);                                                   % characteristics for simulation
        indx1=randsample(length(y),I,'false');                          % randomly choose household income
        y1=y(indx1,:);                                                  % income for simulation
        X2=log(X1');                                                    % log transformation of continuous characteristics
        A=(1:1:I)';                                                     % initial assignment (random)
        priceold=zeros(I,1);    price=ones(I,1);                        % initial prices                                     
        it=0;                                                           % initial iteration
        %---------------------------------------------------------------%
        %   a.  define preferences for sample of households             %
        %---------------------------------------------------------------%
        alpha1=gamrnd(beta(1),beta(2),I,K);                             % draw info on preferences        
        alpha1=(ones(I,1)*beta(3:end)).*alpha1./((y1/1000)*ones(1,K));  % disutility from negative characteristics   
        u=alpha1*X2;                                                    % utility from all homes
        [a b]=min(u');                                                  % lowest utility    
        u1=(y1-min(y1)+1).*diag(exp(alpha1*X2(:,b)));                   % calculate utility from lowest bid
        %---------------------------------------------------------------%
        %   b.  solve for equilibrium price vector using IBA            %
        %---------------------------------------------------------------%
        while max(abs(price-priceold))>tol                              % iterate on price vector
            priceold=price;                                             % update price vector
            for i=1:I                                                   % loop over homes                 
                M=alpha1*X2(:,i);                                       % utility from characteristics
                M=exp(M);                                               % constant in bid function
                bid=y1-u1./M;                                           % current bids for i
                [temp k]=max(bid);                                      % find maximum bidder
                A(i)=k;                                                 % update assignment
                bid(k)=[];                                              % remove from sample
                z=max(bid);                                             % find next highest bid
                price(i)=min(z(1)+sqrt(eps),temp);                      % calculate new price
                u1(k)=(y1(k)-price(i)).*M(k);                           % update utility of mover
            end                                                         %
            it=it+1;  unassigned=I-size(unique(A),1);                   % calculate performance statistics
            fprintf('Iter: %4i  P_min: %7.8f  P_max: %7.8f  P_diff: %.8f  Unassigned: %5.0f  MC: %4.0f\n',it,min(price),max(price),max(abs(price-priceold)),unassigned,mc);   
        end                                                             % 
        t=toc;                                                          % stop stopwatch
        results(mc,:)=[I it t 0 0 min(price) quantile(price,.01) quantile(price,.05) quantile(price,.25) median(price) quantile(price,.75) quantile(price,.95) quantile(price,.99) max(price) mean(price) std(price) skewness(price) kurtosis(price) unassigned];    
        %---------------------------------------------------------------%
        %   c.  produce simulated cdfs and pdfs for FIGURE 3 of paper   %
        %---------------------------------------------------------------%
        figure(1);                                                      % define first figure
        temp=(1:1:I)'; temp1=sortrows([price rent(indx)],2);            % sort prices from lowest to highest
        plot(temp,log(temp1(:,1)),':r',temp,log(temp1(:,2)));           % graph out-of-sample prediction
        xlabel('price rank'); ylabel('log price');                      % label axes
        legend('predicted','actual',2);                                 % add legend
        axis([0,I,7.5,11.5])                                            %
        figure(2);                                                      % define second figure
        [f,xi] = ksdensity(log(price));                                 % graph density of predicted prices
        [f1,xi1] = ksdensity(log(rent(indx))); plot(xi,f,':r',xi1,f1);  % graph density of observed prices
        xlabel('log price'); ylabel('f ( log price )');                 % label axes
        legend('predicted','actual',2);                                 % add legend
        axis([7.5,11.5,0,max([f1 f])*1.1])                              %
        %---------------------------------------------------------------%
        %   d.  solve for equilibrium price vector using Linear Program %
        %---------------------------------------------------------------%
        if I<=1000,
        %---------------------------------------------------------------%
        %            Solve primal LP problem for assignment matrix      %
        %---------------------------------------------------------------%
        tic                                                             % set timer
        priceold=zeros(I,1);    price=ones(I,1);                        % initial prices                                     
        u1=u1.*(1+.1*rand(I,1));                                        % set starting utility
        Aeq=[kron(speye(I),ones(1,I)); kron(ones(1,I),speye(I))];       % shares must sum to 1
        beq=ones(2*I,1);                                                % shares must sum to 1
        lb=zeros(I^2,1);                                                % lower bound on assignment shares
        vold=zeros(I,1); v=ones(I,1);                                   %    
        options=optimset('TolFun',1e-8,'MaxIter',500,'Display','iter'); %
        options1=optimset('TolFun',1e-12,'MaxIter',10000,'Display','iter');   %
        it=0;                                                           %    
        M=alpha1*X2;                                                    % utility from characteristics
        M=exp(M);                                                       % constant in bid function
        M1=M';                                                          % constants in algorithm    
        flag=1;                                                         % convergence flag
        while max(abs(price-priceold))>tol                              % iterate on price vector
            priceold=price;                                             %
            bid=kron(ones(1,I),y1)-kron(ones(1,I),u1)./M;               % current bids for i
            f=reshape(bid',I^2,1);                                      % redefine bid matrix as vector                                                                %
            [A fval exitflag]=linprog(-f,[],[],Aeq,beq,lb,[],[],options); % solve assignment proble
            temp=find(A<.01);  A(temp)=0;                               % remove rounding error on zeros
            temp=find(A>.99);   A(temp)=1;                              % remove rounding error on ones
            temp=find(A>0 & A<1);                                       % find numerical assignment problems
            if exitflag~=1 | min(size(temp))>0,                         % test for numerical problems
                [A fval exitflag]=linprog(-f,[],[],Aeq,beq,lb,[],[],options1);  % try again w/more iterations
                if exitflag~=1, flag=0; end;                            %
            end                                                         %
            A=reshape(A,I,I);                                           % redefine assignment vector as matrix                      
            temp=find(A<.01);  A(temp)=0;                               % remove rounding error on zeros
            temp=find(A>.99);   A(temp)=1;                              % remove rounding error on ones
            %-----------------------------------------------------------%
            %               solve dual LP problem for price vector      %
            %-----------------------------------------------------------%
            temp=find(A'==1);                                           % find assignments for each individaul (by house)
            price=bid(temp);                                            % bids that correspond to assignment (by house)
            v=price-max(bid)';                                          % side payments  (by house)
            v=v-max(v);                                                 % normalize side payments        
            price=price-v;                                              % update price
            %-----------------------------------------------------------%
            %              update utility and the bid matrix            %
            %-----------------------------------------------------------%
            temp=find(A==1);                                            % find assignment
            [a b]=max(A);                                               % find home assigned to each person    
            u1=(y1-price(b)).*(M1(temp));                               % update utility
            if max(price(b)-y1)>0, flag=0; end;                         % check for violation of budget constraint
            if flag==0; break; end                                      %
            it=it+1;                                                    %
        end                                                             %
        t=toc;                                                          %
        results(mc,4:5)=[t flag];                                       %
    end                                                                 %
    %-------------------------------------------------------------------%
    end                                                                 %
    table3=[table3; mean(results); -std(results)];                      % fill in table 3 --> prepare for Excel
    temp=find(results(:,5)==1);                                         %
    table3(end-1,4)=mean(results(temp,4));                              %
    table3(end,4)=-std(results(temp,4));                                %        
    table3(end-1,5)=max(size(temp));                                    %
    table3(end,5)=0;                                                    %
end                                                                     %    
results=[results; N 0 0 min(rent) quantile(rent,.01) quantile(rent,.05) quantile(rent,.25) median(rent) quantile(rent,.75) quantile(rent,.95) quantile(rent,.99) max(rent) mean(rent) std(rent) skewness(rent) kurtosis(rent) 0];
%-----------------------------------------------------------------------%




























