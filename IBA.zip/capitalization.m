%-----------------------------------------------------------------------%
% capitalization_SJ                                                     %
%                                                                       %    
% This file uses the IBA to solve for the hedonic price vector which    %
% defines a new locational equilibrium, following various shocks to the %
% spatial distribution of school quality.  It generates the data for    %
% tables 4 & 5 in the paper.                                            %
%                                                                       %
% Note: the price and structural characteristics of each home have been %
%       randomly shocked in order to avoid violating contract           %
%       obligations with the commercial vendor supplying the data. As a %
%       result, these "fake" housing data cannot be used for any other  %
%       application.  They have no value outside the current simulation.%
%       See the appendix to the paper for details.                      % 
%-----------------------------------------------------------------------%
clear                                                                   % clear all data in workspace
rand('state',2008); randn('state',2008);                                % set seeds on uniform and normal distributions
opt=optimset('Display','iter','TolFun',1e-4,'TolX',1e-4,'MaxIter',1e+6,'MaxFunEval',1e+6); 
%-----------------------------------------------------------------------%
%   1.  LOAD DATA                                                       %
%-----------------------------------------------------------------------%
load sjdata                                                             % load San Joaquin data
%-----------------------------------------------------------------------%
%   2.  DATA DESCRIPTION                                                %
%-----------------------------------------------------------------------%
%       sjprice  --> housing prices                                     %
%       rent     --> annualized rents using formula from Poterba (1992) %
%       API      --> Academic performance index                         %
%       N        --> # observations                                     %
%       K        --> # characteristics                                  %
%       X(:,1)   --> building sqft (10)                                 %
%       X(:,2)   --> lot sqft (1000)                                    %
%       X(:,3)   --> bedrooms (#)                                       %
%       X(:,4)   --> age (years)                                        %
%       X(:,5)   --> % in cesus tract under 18 (%)                      %
%       X(:,6)   --> distance to nearest grazing land (kilometers)      %
%       X(:,7)   --> mean travel time to work in tract (kilometers)     %
%       X(:,8)   --> median household income in tract (1000)            %
%       X(:,9)   --> distance to nearest water body (kilometers)        %
%       X(:,10)  --> STAR mean 10th grade math score (percentile)       %
%       district --> identifier for district in which people live       %
%                       1   =   Lincoln                                 %      
%                       2   =   Lodi                                    %
%                       3   =   Stockton                                %
%                       4   =   Escalon                                 %
%                       5   =   Manteca                                 %
%                       6   =   Ripon                                   %
%                       7   =   Tracy                                   %
%-----------------------------------------------------------------------%
%-----------------------------------------------------------------------%
%   3.  DEFINE INCOME FOR POPULATION OF HOUSEHOLDS                      %
%-----------------------------------------------------------------------%
incmin=[0 5 10 15 20 25 30 35 40 45 50 60 75 100 125 150 200];          % lower bound on income bins
incmax=[5 10 15 20 25 30 35 40 45 50 60 75 100 125 150 200 300];        % upper bound on income bins
inccount=[6942 11376 12234 12129 11924 11794 10694 10603 10187 8940];   % income distribution
inccount=[inccount 16076 19399 19934 9405 4016 3212 2701];              % income distribution
incmin(1)=[];   incmax(1)=[];   inccount(1)=[];                         % drop lowest bin (<$10,000)
y=[];                                                                   %
for i=1:length(inccount)                                                % loop over income bins
    temp=incmin(i)+(incmax(i)-incmin(i))*rand(inccount(i),1);           % draws on income for people in bin
    y=[y; temp*1000];                                                   % concatinate income distribution & convert to dollars
end                                                                     %
%-----------------------------------------------------------------------%
%   4.  GENERATE TABLES 4 AND 5                                         %
%-----------------------------------------------------------------------%
beta=[0.9782 0.1563 123.0416 14.926 -2.0896 -11.9443 -14.2792 -10.1281 3.4123 16.9954 14.4839 11.6313];
I=2000;                                                                  % # of observations
tol=1e-3;                                                               % convergence tolerance on price vector
id1=(1:1:I)';                                                           % id for homes in each simulation
W=zeros(I,8);                                                           % empty matrix for intermediate data
X(:,end)=STAR;                                                          % set school quality
MC=30;                                                                  %
T5=[];                                                                  %
for mc=1:30,                                                            %    
rand('state',mc);  randn('state',mc);                                   % set seeds on uniform and normal distributions
indx=randsample(N,I,'false');                                           % draw I from N without replacement
X1=X(indx,:);                                                           % characteristics for simulation
D=district(indx,:);                                                     % school district id numbers
indx1=randsample(length(y),I,'false');                                  % randomly choose household income
y1=y(indx1,:);                                                          % income for simulation
X2=log(X1');                                                            % log transformation of continuous characteristics
A=(1:1:I)';                                                             % initial assignment (random)
priceold=zeros(I,1);    price=ones(I,1);                                % initial prices                                     
it=0;                                                                   % initial iteration
%-----------------------------------------------------------------------%
%   a.  define preferences for sample of households                     %
%-----------------------------------------------------------------------%
alpha1=gamrnd(beta(1),beta(2),I,K);                                     % draw info on preferences        
alpha1=(ones(I,1)*beta(3:end)).*alpha1./((y1/1000)*ones(1,K));          % disutility from negative characteristics   
u=alpha1*X2;                                                            % utility from all homes
[a b]=min(u');                                                          % lowest utility    
u1=(y1-min(y1)+1).*diag(exp(alpha1*X2(:,b)));                           % calculate utility from lowest bid
unassigned=I;                                                           %
%-----------------------------------------------------------------------%
%   b.  solve for equilibrium price vector using IBA                    %
%-----------------------------------------------------------------------%
while max(abs(price-priceold))>tol | unassigned>0                       % iterate on price vector
    priceold=price;                                                     % update price vector
    for i=1:I                                                           % loop over homes                 
        M=alpha1*X2(:,i);                                               % utility from characteristics
        M=exp(M);                                                       % constant in bid function
        bid=y1-u1./M;                                                   % current bids for i
        [temp k]=max(bid);                                              % find maximum bidder
        A(i)=k;                                                         % update assignment
        bid(k)=[];                                                      % remove from sample
        z=max(bid);                                                     % find next highest bid
        price(i)=min(z(1)+sqrt(eps),temp);                              % calculate new price
        u1(k)=(y1(k)-price(i)).*M(k);                                   % update utility of mover
    end                                                                 %
    it=it+1;  unassigned=I-size(unique(A),1);                           % calculate performance statistics
    fprintf('Iter: %4i  P_min: %7.8f  P_max: %7.8f  P_diff: %.8f  Unassigned: %5.0f\n',it,min(price),max(price),max(abs(price-priceold)),unassigned);   
end                                                                     % 
%-----------------------------------------------------------------------%
%   c.  calculate mean price, income, and WTP by district               %
%-----------------------------------------------------------------------%
temp=sortrows([A (1:1:I)'],1);                                          %
W(:,1:4)=[log(u1) price(temp(:,2)) temp(:,2) D(temp(:,2))];             % [utility price home STAR district] 
X3=X1;  X3(:,end)=X3(:,end)+1;  X3=log(X3');                            % add 1% change to school quality
temp=exp(W(:,1)-diag(alpha1*X3(:,W(:,3))));                             % utility-equalizing income
W(:,5)=temp+W(:,2)-y1;                                                  % MWTP
X3=X1;  X3(:,end)=X3(:,end)+15;  X3=log(X3');                           % add 15% change to school quality
temp=exp(W(:,1)-diag(alpha1*X3(:,W(:,3))));                             % utility-equalizing income
W(:,6)=temp+W(:,2)-y1;                                                  % WTP_PE
W(:,7:8)=[price X1(:,end)];                                             % price0 and quality0
result=[W(:,2) y1 alpha1(:,10).*(y1/1000) -W(:,5) -W(:,6) ];            % collect results for table 4   
temp=find(W(:,4)==1);    Lincoln=mean(result(temp,:),1);                % save results for average Lincoln resident
temp=find(W(:,4)==2);    Lodi=mean(result(temp,:),1);                   % save results for average Lodi resident 
temp=find(W(:,4)==3);    Stockton=mean(result(temp,:),1);               % save results for average Stockton resident
temp=find(W(:,4)==4);    Escalon=mean(result(temp,:),1);                % save results for average Escalon resident
temp=find(W(:,4)==5);    Manteca=mean(result(temp,:),1);                % save results for average Manteca resident
temp=find(W(:,4)==6);    Ripon=mean(result(temp,:),1);                  % save results for average Ripon resident
temp=find(W(:,4)==7);    Tracy=mean(result(temp,:),1);                  % save results for average Tracy resident
SanJoaquin=mean(result);                                                % save results for entire county
%-----------------------------------------------------------------------%
%   d.  solve for equilibria as initial utility changes                 %
%-----------------------------------------------------------------------%
flag=0;                                                                 % indicator for decrease in prices
s=0;
T5_temp=[];                                                             % empty results matrix for table 5
while flag==0,                                                          %
    %-------------------------------------------------------------------%
    %   SHOCK STOCKTON OR MANTECA                                       %      
    %-------------------------------------------------------------------%                  
    X1=X(indx,:);                                                       % reset characteristics
    temp=find(D==3);                                                    % find STOCKTON homes
%     temp=find(D==5);                                                    % find MANTECA homes
    X1(temp,end)=X1(temp,end)+15;   X2=log(X1');                        % increase school quality
    X3=X1;  X3(:,end)=X3(:,end)+15;  X3=log(X3');                       % increase school quality
    if s==0,                                                            %
        temp=exp(W(:,1)-diag(alpha1*X3(:,W(:,3))));                     % utility-equalizing income
        W(:,9)=temp+W(:,2)-y1;                                          % WTP_PE
        temp=min([y1-1,W(:,2)+max(abs(W(:,9)))]')';                     % calculate max possible price rise
        u1=(y1-temp).*diag(exp(alpha1*X2(:,W(:,3))));                   % update utility   
    else,                                                               %
    u1=u1+.1;
    end                                                                 %
    %-------------------------------------------------------------------%
    %   e.  solve for a new equilibrium                                 %      
    %-------------------------------------------------------------------%  
    priceold=zeros(I,1);    price=ones(I,1);    it=0;                   % initial iteration
    while max(abs(price-priceold))>tol | unassigned>0                   % iterate on price vector
        priceold=price;                                                 % update price vector
        for i=1:I                                                       % loop over homes                 
            M=alpha1*X2(:,i);                                           % utility from characteristics
            M=exp(M);                                                   % constant in bid function
            bid=y1-u1./M;                                               % current bids for i
            [temp k]=max(bid);                                          % find maximum bidder
            A(i)=k;                                                     % update assignment
            bid(k)=[];                                                  % remove from sample
            z=max(bid);                                                 % find next highest bid
            price(i)=min(z(1)+sqrt(eps),temp);                          % calculate new price
            u1(k)=(y1(k)-price(i)).*M(k);                               % update utility of mover
        end                                                             %
        it=it+1;  unassigned=I-size(unique(A),1);                       % calculate performance statistics
        fprintf('Iter: %4i  P_min: %7.8f  P_max: %7.8f  P_diff: %.8f  Unassigned: %5.0f  S: %4.0f  MC: %4.0f\n',it,min(price),max(price),max(abs(price-priceold)),unassigned,s,mc);   
    end                                                                 % 
    %-------------------------------------------------------------------%
    %   f.  use FD estimator to calculate capitalization rates          %
    %-------------------------------------------------------------------%
    Y=price-W(:,7);                                                     % price change
    B=X1(:,end)-W(:,8);                                                 % constant & quality change
    temp=find(B~=0);                                                    % homes with quality changes
    temp1=find(B==0);                                                   % homes without quality changes   
    cap_rate_pure=mean(Y(temp)./B(temp));                               %
    cap_rate_relative=(mean(Y(temp))-mean(Y(temp1)))./mean(B(temp));    %
    if cap_rate_pure>0,                                                 %    
        T5_temp=[T5_temp; cap_rate_pure cap_rate_relative Stockton(end-1) SanJoaquin(end-1)]; % STOCKTON
%         T5_temp=[T5_temp; cap_rate_pure cap_rate_relative Manteca(end-1) SanJoaquin(end-1)]; % MANTECA
        s=s+1;
    else, flag=1;                                                       %
    end                                                                 %
end                                                                     %  
if isempty(T5_temp)==0,
    T5=[T5; min(T5_temp(:,2)) max(T5_temp(:,2)) T5_temp(1,3) T5_temp(1,4)]; 
end                                                                     %
%-----------------------------------------------------------------------%
end                                                                     %
T5=[mean(T5); std(T5)];                                                 % Table 5 results for given N and school district
%-----------------------------------------------------------------------%




























