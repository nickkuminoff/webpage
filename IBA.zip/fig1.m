%-----------------------------------------------------------------------%
% fig1                                                                  %
%                                                                       %    
% This file solves for an equilibrium in the three-community example    %
% presented in the paper and summarized in table 1. It also creates a   %
% movie of the shrinking hyperrectangle shown in figure 1 of the paper. % 
% It calls the file "voxel.m".                                          %
%-----------------------------------------------------------------------%
clear                                                                   % clear all data in workspace
%-----------------------------------------------------------------------%
%        DEFINE THREE HOUSES AND HOUSEHOLDS TO ILLUSTRATE IBA           %
%-----------------------------------------------------------------------%
I=3;                                                                    % sample size for simulation
X1 = [ 2.5,11.6173,1584,12.8787,17.3864,32,37.1761,95.1793;             %
       2.5,11.5425,1440,2.8498,4.0233,22,22.6972,85.3752;               %
       3.5,13.6635,6386,1.0298,5.6159,20,26.5998,76.7463 ];             %
alpha1=[ 0.6209,0.504,0.2891,0.3919,0.3127,0.574,0.8812,0.2375;         %    
         1.6088,0.6747,0.7432,1.1252,2.0942,0.2054,0.895,0.9476;        %    
         0.3244,0.1881,0.1116,1.7249,2.6627,0.2082,0.3198,0.3442];      %    
y1=[68910;64500;57000;];                                                % income
X2=log(X1');                                                            % log transformation of characteristics
temp=alpha1*X2;                                                         % utility from housing characteristics
u=log(1)+temp(:,1);                                                     % utility from initial assignment
%-----------------------------------------------------------------------%
%              DEFINE NONNEGATIVE PORTION OF BID STRINGS                %
%-----------------------------------------------------------------------%
bid1=[]; bid2=[]; bid3=[];                                              %
for i=1:1000                                                            %
    bid=kron(ones(1,I),y1)-exp(kron(ones(1,I),u))./exp(alpha1*X2);      % initial bids
    bid1=[bid1; bid(1,:)];                                              %
    bid2=[bid2; bid(2,:)];                                              %
    bid3=[bid3; bid(3,:)];                                              %
    u=u*1.001;                                                          %
end                                                                     %
temp1=min([max(find(bid1(:,1)>0)) max(find(bid1(:,2)>0)) max(find(bid1(:,3)>0))]);
temp2=min([max(find(bid2(:,1)>0)) max(find(bid2(:,2)>0)) max(find(bid2(:,3)>0))]);
temp3=min([max(find(bid3(:,1)>0)) max(find(bid3(:,2)>0)) max(find(bid3(:,3)>0))]);
bid1=bid1(1:temp1,:)./1000;                                             %
bid2=bid2(1:temp2,:)./1000;                                             %
bid3=bid3(1:temp3,:)./1000;                                             %
%-----------------------------------------------------------------------%
%          PRECALCULATE CONSTANTS AND STARTNG VALUES FOR IBA            %
%-----------------------------------------------------------------------%
temp=alpha1*X2;                                                         %
u1=log(1)+temp(:,1);                                                    % utility from initial assignment
bid=kron(ones(1,I),y1)-exp(kron(ones(1,I),u1))./exp(alpha1*X2);         % initial bids from inital utility
u1=(y1-bid(:,1)).*exp(alpha1*X2(:,1));                                  % initial utility (without logs)
A=(1:1:I)';                                                             % initial assignment (random)
priceold=zeros(I,1);    price=ones(I,1);                                % initial prices                                     
it=0;                                                                   % initial iteration
price1=max(bid)./1000;                                                  %    
clear bid                                                               %
%-----------------------------------------------------------------------%
%       SOLVE FOR EQUILIBRIUM PRICE VECTOR USING IBA                    %
%-----------------------------------------------------------------------%
frame=1;                                                                %
plot3(bid1(:,1),bid1(:,2),bid1(:,3),'k','LineWidth',2)                  %    
hold on                                                                 %            
plot3(bid2(:,1),bid2(:,2),bid2(:,3),'k','LineWidth',1)                  %
plot3(bid3(:,1),bid3(:,2),bid3(:,3),'k','LineWidth',3)                  %
grid on                                                                 %
xlabel('P_1','Position',[476.592 435.97 157.507])                       %
ylabel('P_2','Position',[516.68 387.189 155.918])                       %
zlabel('P_3')                                                           %
legend('A','B','C','Location','East')                                   %
hold off                                                                %
view(129,16)                                                            %
axis([0,70,0,70,0,70])                                                  %
voxel([0,0,0],price1,'y',.75)                                           %
F(frame)=getframe(gcf);                                                 %
frame=frame+1;                                                          %
bidrecord=[];                                                           %
pricerecord=[];                                                         %
prices=[];                                                              %
while max(abs(price-priceold))>0                                        % iterate on price vector
    bidrec=[];                                                          %
    pricerec=[];                                                        %
    priceold=price;                                                     % update price vector
    for i=1:I                                                           % loop over homes                 
        M=alpha1*X2(:,i);                                               % utility from characteristics
        M=exp(M);                                                       % constant in bid function
        bid=y1-u1./M;                                                   % current bids for i
        bidrec=[bidrec bid];                                            %
        [temp k]=max(bid);                                              % find maximum bidder
        A(i)=k;                                                         % update assignment
        bid(k)=[];                                                      % remove from sample
        z=max(bid);                                                     % find next highest bid
        price(i)=min(z(1)+1,temp);                                      % calculate new price
        u1(k)=(y1(k)-price(i)).*M(k);                                   % update utility of mover
        price1(i)=price(i)./1000;                                       %
        plot3(bid1(:,1),bid1(:,2),bid1(:,3),'k','LineWidth',2)          %
        hold on                                                         %
        plot3(bid2(:,1),bid2(:,2),bid2(:,3),'k','LineWidth',1)          %
        plot3(bid3(:,1),bid3(:,2),bid3(:,3),'k','LineWidth',3)          %
        voxel([0,0,0],price1,'y',1)                                     %
        grid on                                                         %
        axis([0,70,0,70,0,70])                                          %
        xlabel('P_1','Position',[476.592 435.97 157.507])               %
        ylabel('P_2','Position',[516.68 387.189 155.918])               %
        zlabel('P_3')                                                   %
        legend('A','B','C','Location','East')                           %
        hold off                                                        %
        view(129,16)                                                    %
        F(frame)=getframe(gcf);                                         %
        frame=frame+1;                                                  %
        pricerec=[pricerec price];                                      %
        prices=[prices; price'];                                        %    
    end                                                                 %
    it=it+1;  homeless=I-size(unique(A),1);                             % calculate performance statistics
    fprintf('Iter: %4i  P_min: %7.8f  P_max: %7.8f  Homeless: %5.0f\n',it,min(price),max(price),homeless);   
    bidrecord=[bidrecord; [it*ones(3,1) bidrec]];                       % data used for table 1
    pricerecord=[pricerecord; [it*ones(3,1) pricerec]];                 % data used for table 1
end                                                                     %
%-----------------------------------------------------------------------%
%          DRAW FIGURE FOR 3-D CASE                                     %
%-----------------------------------------------------------------------%
clf                                                                     %
axes('Position',[0 0 1 1])                                              %
movie(F,[3 1 2 3 4 5 6 7 8 9 10 11],1)                                  % play movie three times
%-----------------------------------------------------------------------%

























